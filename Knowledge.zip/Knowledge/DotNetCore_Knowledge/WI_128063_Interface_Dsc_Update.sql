--Execute in SecurityManagement Database, only 1 Row should update
DECLARE	@TestMode	BIT = 1

BEGIN TRAN

BEGIN TRY

	Update RS_Interface set Interface_Dsc = 'Recon Maintenance'   where Interface_Dsc = 'Seller Recon Maintenance'

END TRY

BEGIN CATCH

	--Rollback transaction
	IF @@TRANCOUNT > 0
		ROLLBACK TRAN;

	PRINT '';
	THROW;

END CATCH

--Commit transaction
IF @@TRANCOUNT > 0
BEGIN

	IF @TestMode = 1
	BEGIN
		ROLLBACK TRAN

		PRINT ''
		PRINT 'Script test successful, changes rolled back'
	END
	ELSE
	BEGIN
		COMMIT TRAN

		PRINT ''
		PRINT 'Script successful, committing changes'
	END

END