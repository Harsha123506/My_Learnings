﻿namespace My_new_API.Models
{
    public class Difficulty
    {      
        public Guid Id { get; set; }
        public string Name { get; set; }
    }

}
