﻿namespace My_new_API.DTO_s
{
    public class DifficultyDTO
    {
        public string Name { get; set; }
    }
}
