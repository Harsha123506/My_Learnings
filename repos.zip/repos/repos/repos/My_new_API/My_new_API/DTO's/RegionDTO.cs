﻿namespace My_new_API.DTO_s
{
    public class RegionDTO
    {
        public string Name { get; set; }
        public string ImageUrl { get; set; }
        public string code { get; set; }
    }
}
